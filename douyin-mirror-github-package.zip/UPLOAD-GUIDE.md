# 抖音直播镜像 · GitHub 上传包说明

这个压缩包是给 GitHub 用的，里面有**两样东西**：

```
douyin-mirror/               ← 要做成仓库的全部源码和文档（不要带 .git、sdks/、dist/）
DouyinMirror-1.0.1.zip       ← 已经编好的发布包，作为 Release 附件上传
上传说明.md                   ← 本文件
```

## 一、仓库内容（douyin-mirror/）

| 路径 | 说明 |
| --- | --- |
| `src/Mirror.m` | 插件主体源码（约 700 行，中文注释） |
| `build.sh` | 编译脚本，自动找 Xcode / `sdks/` 里的 SDK |
| `scripts/get-sdk.sh` | 没装 Xcode 时下载 iOS SDK |
| `scripts/package.sh` | 编译 + 打包 Release zip |
| `Makefile`、`control` | Theos 用（有 Theos 才能 `make package`，可选） |
| `docs/RELEASE.md` | 发版步骤 |
| `docs/preview.svg` | README 里的效果示意图 |
| `README.md`、`CHANGELOG.md`、`LICENSE`、`.gitignore` | 文档与许可 |

**不要**把 `sdks/`（约 221MB 的 iOS SDK）传上去，`.gitignore` 已经排除；别人 clone 后跑
`./scripts/get-sdk.sh` 或装 Xcode 就能编。

## 二、上传方式 A：GitHub 网页（推荐给 GPT 操作）

1. 新建仓库：名字 `douyin-mirror`，**Public**，不要勾选初始化 README/.gitignore/LICENSE。
2. 打开仓库页 → **Add file → Upload files**。
3. 把 `douyin-mirror/` 里的所有文件（含 `.gitignore`、`src/`、`scripts/`、`docs/`）拖进去，
   提交信息填 `feat: 抖音直播镜像开关 1.0.1`。
4. 建 Release：**Releases → Draft a new release**
   - Tag：`v1.0.1`（不存在就让 GitHub 新建）
   - 标题：`1.0.1 — 修复镜像几秒后自动恢复`
   - 说明：复制 `CHANGELOG.md` 中 1.0.1 一节
   - 附件：上传 `DouyinMirror-1.0.1.zip`
   - **Publish release**

> 网页上传对隐藏文件（`.gitignore`）有时不显示：在 Finder 里按 `⌘ + ⇧ + .` 让隐藏文件可见再拖。

## 三、上传方式 B：本机 git 推送

如果直接在装了 git 的 Mac 上操作，比网页更省事：

```bash
cd douyin-mirror
git remote add origin git@github.com:<你的用户名>/douyin-mirror.git
git branch -M main
git push -u origin main
git push origin --tags
```

（本地仓库已经提交好并打了 `v1.0.1` tag，只需要换成自己的 remote 地址。）

## 四、Release 附件

`DouyinMirror-1.0.1.zip` 里是：

- `DouyinMirror.dylib` — arm64 + arm64e 双架构、ad-hoc 签名、`minos 15.0`
- `README.md`、`CHANGELOG.md`、`LICENSE`

用户下载后解压，用 **TrollFools** 注入抖音即可，不需要越狱。

## 五、提醒

- 提交身份用的是占位值 `lemontea <lemontea@users.noreply.github.com>`，要换成自己的邮箱：
  `git config user.email "你的邮箱" && git commit --amend --reset-author --no-edit` 再重新打 tag。
- 二进制是用 **iPhoneOS 16.5 SDK** 编的，和用户实测通过的那个版本一致；用 Xcode 26.3 的 SDK 也能编，
  但没在真机上验证过，不建议直接拿去发版。
