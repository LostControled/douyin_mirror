# 抖音直播镜像 · DouyinMirror

给抖音的直播画面加一个「⇋」悬浮按钮：**点一下水平镜像，再点一下恢复**，用来对照镜像画面、试妆试衣、或者拍对着前置摄像头的合拍视频。

<img src="docs/preview.svg" width="220" alt="悬浮按钮示意">

- 不需要越狱：用 **TrollFools** 把 `DouyinMirror.dylib` 注入已安装的抖音
- 只动画面层，弹幕、评论、礼物动画、按钮都不受影响（默认模式）
- 状态和按钮位置都会记住，下次打开抖音还在
- 当前版本 **1.0.1**，产物 `dist/DouyinMirror.dylib`（arm64 + arm64e）

---

## 一、安装

### 0. 前提

| 项目 | 要求 |
| --- | --- |
| 系统 | iOS 14.0 – 16.6.1 / 17.0（TrollStore 支持的范围），开发时针对 **iOS 16.3.1** |
| 环境 | 已安装 [TrollStore](https://github.com/opa334/TrollStore) |
| 工具 | 已安装 [TrollFools](https://github.com/Lessica/TrollFools)（`.tipa`，TrollStore 生态的注入工具） |

TrollFools 的安装：Safari 打开它的 Releases 页 → 下载 `TrollFools.tipa` → 在「文件」里长按 → 共享 → 用 TrollStore 打开。

### 1. 把 dylib 传到手机

下载本仓库 Release 里的 `DouyinMirror-1.0.1.zip`，解压出 `DouyinMirror.dylib`，用 AirDrop / 微信文件传输 / iCloud 云盘放进「文件」App。

### 2. 注入

1. 打开 **TrollFools**
2. 在应用列表里点 **抖音**
3. 点右下角 **+ / 注入**，选择 `DouyinMirror.dylib`
4. 注入完成后 TrollFools 会提示，**杀掉抖音后台再重新打开**

重新打开抖音，进入任意直播间，右侧会出现蓝色圆形按钮「⇋」，点一下即可镜像。

> 升级插件：用 TrollFools 对抖音「移除注入」，再按上面步骤注入新版本即可。

---

## 二、使用

| 操作 | 效果 |
| --- | --- |
| 点按按钮 | 开 / 关镜像（开启时按钮变蓝、图标变成「整」表示整页模式） |
| 拖动按钮 | 换位置，位置会记住 |
| 长按按钮 | 菜单：关闭镜像 / 仅镜像视频画面 / 镜像整个画面 |

长按菜单里还会显示**当前识别到的画面层**和**被抖音重置的次数**，方便排查「翻了又弹回去」的情况。

**两种模式**

- **仅镜像视频画面**（推荐，默认）：只翻转直播视频层，弹幕、评论、礼物、按钮都是正常的。抖音改动画面层结构时会换成兜底方案。
- **镜像整个画面**：整页镜像，文字也会跟着反。当「仅镜像视频画面」抓不到画面层（部分抖音版本在独立渲染进程里画视频）时用它。

---

## 三、从源码编译

**装了 Xcode**：直接跑 `./build.sh`，脚本会自动找 Xcode（含装在 `~/Downloads`、`~/Applications` 这类非标准位置的情况）并用它自带的 iOS SDK。

**只有 Command Line Tools**（`xcode-select --install`）：

```bash
./scripts/get-sdk.sh          # 下载 iOS SDK 到 sdks/（约 200MB，GitHub 走 gh-proxy 镜像）
./build.sh                    # 编译，产物在 dist/DouyinMirror.dylib
```

- SDK 查找顺序：`SDK=` 环境变量 → `sdks/iPhoneOS*.sdk` → 已装 Xcode 的 iphoneos SDK
- 手动指定：`SDK=/path/to/iPhoneOS16.5.sdk ./build.sh`
- 只编一个架构：`ARCHES=arm64 ./build.sh`（默认 `arm64 arm64e`）
- 有 Theos 的话 `make package` 也能编（`Makefile` 已配好）

已验证的编译环境：Xcode 26.3 + iPhoneOS 26.2 SDK（`minos 15.0`）、Command Line Tools + iPhoneOS 16.5 SDK，编译零警告，产物 arm64 + arm64e。`clang --analyze` 静态分析无告警。

产物是 fat dylib，`install_name` 为 `@executable_path/Frameworks/DouyinMirror.dylib`，并做了 ad-hoc 签名。

---

## 四、原理

抖音是 App Store 版，没有符号表可用，所以插件走的是「运行时扫描视图树」的路子，不依赖任何私有类名：

1. **找画面层**：每 0.2 秒扫一遍前台窗口的视图树，给每个候选打一个分——自身图层是 `AVPlayerLayer` 之类得 100 分，子树里有渲染层得 90 分，类名里带 `Player`/`Render`/`GL` 之类的依次递减，最后用「面积足够大 + 层级足够深」兜底。同分取面积大的。
2. **翻画面层**：给选中的图层（优先翻它的容器层，避免被 AVFoundation 起播时重置）设 `CATransform3DMakeScale(-1, 1, 1)`，每 0.2 秒复检一次，被 App 改回去就立刻补上。目标带「粘性」：只要它还在屏幕上就一直用它，不会因为某次扫描结果抖动而闪回。
3. **悬浮按钮**：单独开一个 `UIWindowLevelAlert + 100` 的透明窗口，重写 `hitTest:` 让空白区域不拦截触摸——否则整页模式下按钮自己也会被镜像、还会挡住抖音的点击。

整页模式则是把窗口根视图镜像，视频、背景、文字一起翻。

---

## 五、已知限制

- 抖音每次大版本更新都可能改直播页结构。「仅镜像视频画面」依赖视图树形态，抓不到时会退化成整页模式（按钮变「整」）。长按菜单里的「当前识别」可以直接看出抓到的是哪一层。
- 如果某一版抖音把视频画在**独立进程**的 Layer 上（跨进程渲染），当前方案翻转不到它，只能用整页模式。
- 整页模式下文字是反的，这是预期的（镜像画面本身就是给对照用的）。
- 只测试过 iOS 16.3.1 + TrollStore 2 + TrollFools；其他系统版本理论上兼容，但没有逐一验证。

---

## 六、常见问题

**Q：翻了，但过几秒自己弹回原样？**
1.0.1 已经针对这个修过：改成翻容器层、目标粘性锁定、0.2 秒复检。如果仍然出现，长按菜单看「被重置 N 次」是不是一直在涨——涨就说明这一版抖音在持续重置该图层，直接切「镜像整个画面」更稳。

**Q：根本找不到视频画面层（提示「没找到视频画面层」）？**
同样长按切「镜像整个画面」。

**Q：按钮跑到屏幕外面去了？**
按钮位置按屏幕比例存，换分辨率不会跑丢；真丢了可以删掉抖音的偏好设置再重新注入。

**Q：注入后抖音打不开 / 闪退？**
先在 TrollFools 里移除注入，确认抖音恢复正常，再把日志（`控制台` 里搜 `DouyinMirror`）发到 Issues。

---

## 七、更新记录

### 1.0.1
- 修「镜像只能维持几秒就恢复」：翻转目标从渲染层改成它的容器层（避免 AVFoundation 起播/换分辨率时重置 transform）
- 目标改为「粘性锁定」：扫描结果抖动时不再来回切换，找不到画面层也不会立刻还原
- 轮询间隔 0.5s → 0.2s
- 长按菜单显示当前锁定层与被重置次数

### 1.0.0
- 首个版本：悬浮按钮 + 视图树扫描 + 单层镜像 + 整页镜像兜底

---

## 八、许可

[MIT](LICENSE)
