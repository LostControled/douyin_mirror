#!/bin/bash
# 用 Xcode 命令行工具(clang) + iOS SDK，把源码编译成可注入的 dylib
#
#   ./build.sh                          # 自动找 SDK：sdks/ > 已装的 Xcode > CLT
#   SDK=/path/to/iPhoneOS16.5.sdk ./build.sh
#   ARCHES="arm64" ./build.sh
#
# Xcode 和 Command Line Tools 二选一都行：装了 Xcode 就用它的 iOS SDK，
# 没装 Xcode 就把 ./scripts/get-sdk.sh 下好的 SDK 放进 sdks/。
set -euo pipefail
cd "$(dirname "$0")"

# Xcode 不在 /Applications 里时（比如放在 ~/Downloads），xcrun 认不到它，
# 这里顺手找一下，省得每次手动 export DEVELOPER_DIR。
if [ -z "${DEVELOPER_DIR:-}" ]; then
  for app in /Applications/Xcode*.app "$HOME"/Applications/Xcode*.app \
             "$HOME"/Downloads/Xcode*.app "$HOME"/Desktop/Xcode*.app; do
    if [ -d "$app/Contents/Developer" ]; then
      export DEVELOPER_DIR="$app/Contents/Developer"
      echo "==> 使用 Xcode: $app"
      break
    fi
  done
fi

if [ -z "${SDK:-}" ]; then
  for d in "$PWD"/sdks/iPhoneOS*.sdk; do
    [ -d "$d" ] && SDK="$d" && break
  done
fi
if [ -z "${SDK:-}" ]; then
  SDK="$(xcrun --sdk iphoneos --show-sdk-path 2>/dev/null || true)"
fi
SDK="${SDK:-$PWD/sdks/iPhoneOS16.5.sdk}"
SRC="$PWD/src/Mirror.m"
OUT="$PWD/dist"
OBJ="$OUT/obj"
MIN_IOS="${MIN_IOS:-15.0}"
ARCHES="${ARCHES:-arm64 arm64e}"
NAME="DouyinMirror"

CLANG="$(xcrun --find clang 2>/dev/null || command -v clang)"

if [ ! -d "$SDK" ]; then
  echo "✗ 找不到 iOS SDK: $SDK"
  echo "  把 iPhoneOS*.sdk 放进 sdks/ 目录，或用 SDK=/路径 ./build.sh 指定"
  echo "  也可以先跑 ./scripts/get-sdk.sh 自动下载"
  exit 1
fi
if [ ! -f "$SDK/System/Library/Frameworks/UIKit.framework/UIKit.tbd" ] && \
   [ ! -f "$SDK/System/Library/Frameworks/UIKit.framework/Headers/UIKit.h" ]; then
  echo "✗ $SDK 看起来不是完整的 iOS SDK"
  exit 1
fi

mkdir -p "$OUT" "$OBJ"
rm -f "$OUT/$NAME.dylib" "$OBJ"/*.o

COMMON=(
  -fobjc-arc -Os -fvisibility=hidden
  -isysroot "$SDK"
  -miphoneos-version-min="$MIN_IOS"
  -DNDEBUG -Wall -Wno-unused-function -Wno-deprecated-declarations
  -I"$SDK/usr/include"
)

for ARCH in $ARCHES; do
  echo "==> 编译 $ARCH"
  if ! "$CLANG" -c "$SRC" \
        -target "$ARCH-apple-ios$MIN_IOS" \
        -arch "$ARCH" "${COMMON[@]}" \
        -o "$OBJ/$NAME-$ARCH.o" 2>"$OBJ/$ARCH.log"; then
    echo "   $ARCH 编译失败，日志:"; sed -n '1,40p' "$OBJ/$ARCH.log"; exit 1
  fi
done

echo "==> 链接"
LIPO="$(xcrun --find lipo 2>/dev/null || command -v lipo)"
rm -f "$OBJ"/*.dylib

for ARCH in $ARCHES; do
  "$CLANG" -dynamiclib \
    -target "$ARCH-apple-ios$MIN_IOS" \
    -isysroot "$SDK" -miphoneos-version-min="$MIN_IOS" -arch "$ARCH" \
    -framework UIKit -framework Foundation -framework QuartzCore -framework CoreGraphics \
    -L"$SDK/usr/lib" \
    "$OBJ/$NAME-$ARCH.o" \
    -install_name "@executable_path/Frameworks/$NAME.dylib" \
    -o "$OBJ/$NAME-$ARCH.dylib" 2>"$OBJ/link-$ARCH.log" || {
      echo "   $ARCH 链接失败："; sed -n '1,20p' "$OBJ/link-$ARCH.log"; rm -f "$OBJ/$NAME-$ARCH.dylib";
    }
done

if [ -f "$OBJ/$NAME-arm64.dylib" ] && [ -f "$OBJ/$NAME-arm64e.dylib" ]; then
  "$LIPO" -create "$OBJ/$NAME-arm64.dylib" "$OBJ/$NAME-arm64e.dylib" -output "$OUT/$NAME.dylib"
elif [ -f "$OBJ/$NAME-arm64.dylib" ]; then
  echo "   （只产出 arm64）"
  cp "$OBJ/$NAME-arm64.dylib" "$OUT/$NAME.dylib"
else
  echo "✗ 链接失败"; exit 1
fi

# ad-hoc 签名（TrollFools 注入时会自己处理签名，签名失败也不影响源码交付）
codesign -f -s - "$OUT/$NAME.dylib" >/dev/null 2>&1 || true

echo "==> 完成: $OUT/$NAME.dylib"
file "$OUT/$NAME.dylib"
"$(xcrun --find lipo)" -info "$OUT/$NAME.dylib" 2>/dev/null || true
