#!/bin/bash
# 编译 + 打包成可以直接上传到 GitHub Release 的 zip
set -euo pipefail
cd "$(dirname "$0")/.."

VERSION="$(sed -n 's/^Version: *//p' control)"
NAME="DouyinMirror"
DIR="dist/package"

./build.sh

rm -rf "$DIR" "dist/$NAME-$VERSION.zip"
mkdir -p "$DIR"
cp "dist/$NAME.dylib" README.md CHANGELOG.md LICENSE "$DIR/"
(cd "$DIR" && zip -q -r "../$NAME-$VERSION.zip" "$NAME.dylib" README.md CHANGELOG.md LICENSE)

echo
echo "==> 打包完成: dist/$NAME-$VERSION.zip"
unzip -l "dist/$NAME-$VERSION.zip"
