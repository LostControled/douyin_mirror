#!/bin/bash
# 下载一份 iOS SDK 到 sdks/ 目录（编译 dylib 用，不需要完整 Xcode）
#
#   ./scripts/get-sdk.sh              # 默认 iPhoneOS16.5.sdk
#   ./scripts/get-sdk.sh 16.5
#
# 下载源：theos/sdks 仓库。github.com 在国内常常连不上，这里默认走 gh-proxy 镜像；
# 能直连的话可以用 MIRROR= 关掉代理。
set -euo pipefail
cd "$(dirname "$0")/.."

VER="${1:-16.5}"
NAME="iPhoneOS${VER}.sdk"
DEST="sdks"
ZIP="$(mktemp -t sdks)"

if [ -d "$DEST/$NAME" ]; then
  echo "✓ 已经存在: $DEST/$NAME"
  exit 0
fi

MIRROR="${MIRROR-https://gh-proxy.com/}"
URL="${MIRROR}https://github.com/theos/sdks/archive/refs/heads/master.zip"

echo "==> 下载 SDK 仓库（约 200MB，来自 theos/sdks）"
echo "    $URL"
curl -L --fail --progress-bar "$URL" -o "$ZIP"

echo "==> 解压 $NAME"
TMP="$(mktemp -d)"
unzip -q "$ZIP" -d "$TMP"
mkdir -p "$DEST"
SRC="$TMP/sdks-master/$NAME"
if [ ! -d "$SRC" ]; then
  echo "✗ 压缩包里没有 $NAME，可用版本："
  ls "$TMP/sdks-master" | tr '\n' ' '
  echo
  exit 1
fi
cp -R "$SRC" "$DEST/"
rm -rf "$TMP" "$ZIP"

echo "==> 完成: $DEST/$NAME"
du -sh "$DEST/$NAME"
