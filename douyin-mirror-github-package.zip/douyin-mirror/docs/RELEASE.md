# 发布到 GitHub

## 1. 建仓库

在 GitHub 上新建一个空仓库（不要勾选自动生成 README/.gitignore）：

- 名字建议：`douyin-mirror`
- 可见性：Public（想私有也行，Release 附件同样能下载）

## 2. 推代码

本地仓库已经在 `douyin-mirror/` 里初始化好并提交过 `v1.0.1`，只需要加 remote 再推：

```bash
cd douyin-mirror
git remote add origin git@github.com:<你的用户名>/douyin-mirror.git
git branch -M main
git push -u origin main
git push origin --tags
```

> 用的是 HTTPS 的话把地址换成 `https://github.com/<你的用户名>/douyin-mirror.git`，
> 或者可以直接 `git remote add origin https://github.com/<用户名>/<仓库>.git`。

## 3. 打包发布文件

```bash
./scripts/package.sh
# 产物：dist/DouyinMirror-1.0.1.zip
```

zip 里是 `DouyinMirror.dylib` + README + CHANGELOG + LICENSE，用户解压后把 dylib 用 TrollFools 注入即可。

## 4. 建 Release

1. 仓库页右边 **Releases** → **Draft a new release**
2. **Choose a tag** 选 `v1.0.1`（步骤 2 已经推上去）
3. 标题：`1.0.1 — 修复镜像几秒后自动恢复`
4. 说明：直接复制 `CHANGELOG.md` 里 1.0.1 那一节
5. 附件：把 `dist/DouyinMirror-1.0.1.zip` 拖进去
6. **Publish release**

README 里写的是「下载 Release 里的 `DouyinMirror-1.0.1.zip`」，发版后可核对一下文件名一致。

## 5. 之后改版本号要动的地方

- `control` 里的 `Version:`
- `CHANGELOG.md` 加一节
- README 顶部「当前版本」和安装一节的 zip 文件名
- 打完包 `git tag vX.Y.Z && git push origin --tags`，再发 Release
