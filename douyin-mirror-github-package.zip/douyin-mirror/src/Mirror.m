// DouyinMirror.m
// 抖音直播「镜像开关」——TrollStore / TrollFools 注入版
//
// 设计要点：
//   * 不依赖 CydiaSubstrate / libhooker / ElleKit，只用 ObjC runtime + UIKit，
//     因此可以被 TrollFools 直接注入 App Store 版抖音（无需越狱）。
//   * 不硬编码抖音的私有类名（版本一变就失效），改为运行时扫描视图树，
//     按「图层类型 + 类名关键字 + 面积」给候选视图打分，取最高分的那一层做镜像。
//   * 镜像作用在 CALayer.transform 上，只翻转视频画面，弹幕/评论/按钮不受影响。
//   * 悬浮按钮放在独立的 UIWindow 里，所以「整页镜像」模式下按钮不会被翻转。

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>

#pragma mark - 常量

static NSString *const kEnabledKey = @"com.lemontea.douyinmirror.enabled";
static NSString *const kModeKey    = @"com.lemontea.douyinmirror.mode";     // 0 = 仅视频, 1 = 整页
static NSString *const kPosXKey    = @"com.lemontea.douyinmirror.posx";
static NSString *const kPosYKey    = @"com.lemontea.douyinmirror.posy";
static NSString *const kHintedKey  = @"com.lemontea.douyinmirror.hinted";

#define DYM_LOG(fmt, ...) NSLog((@"[DouyinMirror] " fmt), ##__VA_ARGS__)

#pragma mark - 全局状态

static BOOL      gEnabled  = NO;
static NSInteger gMode     = 0;
static BOOL      gReady    = NO;

static NSTimer  *gTimer      = nil;

@interface DYMOverlayWindow : UIWindow
@end

@interface DYMOverlayController : UIViewController
@property (nonatomic, strong) UIButton *button;
- (void)refreshButton;
- (void)showToast:(NSString *)text;
- (void)presentAlert:(UIAlertController *)alert;
@end

static DYMOverlayWindow     *gWindow  = nil;
static DYMOverlayController *gOverlay = nil;

static CALayer      *gVideoLayer       = nil;   // 当前被镜像的视频层（强引用，切换时释放）
static CATransform3D gVideoOriginal;
static BOOL          gVideoApplied     = NO;

static NSMutableArray<CALayer *> *gFullLayers   = nil;
static NSMutableDictionary<id, NSValue *> *gFullOriginal = nil;

static NSInteger gMissCount = 0;
static NSUInteger gReapplyCount = 0;    // 画面层被抖音还原过多少次
static BOOL gWarnedReset = NO;          // 是否已提示过"频繁被重置"


static void DYMSetEnabled(BOOL on);
static void DYMTick(void);
static CALayer *DYMFindBestLayer(NSInteger *outScore);
static UIWindowScene *DYMActiveScene(void);
static void DYMEnsureOverlay(void);

#pragma mark - 小工具

static NSArray<NSString *> *kRenderLayerKeys;   // AVPlayerLayer 之类
static NSArray<NSString *> *kLiveViewKeys;      // 直播播放器视图
static NSArray<NSString *> *kPlayerKeys;        // 播放器/渲染视图（宽泛）
static NSArray<NSString *> *kLayerKeys;         // 自定义渲染图层

static void DYMInitKeys(void) {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        kRenderLayerKeys = @[@"AVPlayerLayer", @"PlayerLayer", @"VideoLayer"];
        kLiveViewKeys    = @[@"PlayerView", @"LivePlayer", @"VideoPlayer", @"PlayerContainer"];
        kPlayerKeys      = @[@"Player", @"VideoView", @"RenderView", @"GLKView", @"MTKView",
                             @"MetalView", @"CanvasView"];
        kLayerKeys       = @[@"Render", @"Metal", @"GL", @"Canvas"];
    });
}

static BOOL DYMHasKey(NSString *name, NSArray<NSString *> *keys) {
    if (name.length == 0) return NO;
    for (NSString *k in keys) {
        if ([name rangeOfString:k options:NSCaseInsensitiveSearch].location != NSNotFound) return YES;
    }
    return NO;
}

static BOOL DYMIsSystemWindow(UIWindow *w) {
    NSString *cls = NSStringFromClass(w.class);
    if ([cls containsString:@"TextEffects"] || [cls containsString:@"Keyboard"] ||
        [cls containsString:@"StatusBar"]   || [cls containsString:@"Remote"]) {
        return YES;
    }
    if (w.hidden || w.alpha < 0.01) return YES;
    return NO;
}

// 在 depth 层子图层里找 AVPlayerLayer 之类的渲染层
static CALayer *DYMFindRenderSublayer(CALayer *layer, NSInteger depth) {
    if (depth <= 0 || !layer) return nil;
    for (CALayer *sub in layer.sublayers) {
        NSString *cls = NSStringFromClass(sub.class);
        if (DYMHasKey(cls, kRenderLayerKeys)) return sub;
        CALayer *r = DYMFindRenderSublayer(sub, depth - 1);
        if (r) return r;
    }
    return nil;
}

static BOOL DYMHasLabelDescendant(UIView *v, NSInteger depth) {
    if (depth <= 0) return NO;
    for (UIView *sub in v.subviews) {
        if ([sub isKindOfClass:[UILabel class]] || [sub isKindOfClass:[UITextView class]] ||
            [sub isKindOfClass:[UITextField class]]) return YES;
        if (DYMHasLabelDescendant(sub, depth - 1)) return YES;
    }
    return NO;
}

#pragma mark - 扫描：找出最可能是直播画面的图层

typedef struct {
    NSInteger score;
    CGFloat   area;
    __unsafe_unretained CALayer *layer;
} DYMCandidate;

static void DYMWalk(UIView *v, CGRect windowBounds, NSInteger depth, DYMCandidate *best) {
    if (!v || depth > 24) return;

    // 剪枝：完全不可见 / 尺寸过小
    if (v.hidden || v.alpha < 0.01) return;
    CGRect r = [v convertRect:v.bounds toView:nil];
    if (CGRectIsEmpty(r) || r.size.width < 1 || r.size.height < 1) return;
    if (!CGRectIntersectsRect(r, windowBounds)) return;

    CGFloat winArea = windowBounds.size.width * windowBounds.size.height;
    CGFloat area = r.size.width * r.size.height;

    if (winArea > 0 && area >= winArea * 0.15) {
        NSString *viewName  = NSStringFromClass(v.class);
        NSString *layerName = NSStringFromClass(v.layer.class);
        NSInteger score = 0;
        CALayer *target = v.layer;

        // 1) 自身或近几层子图层就是 AVPlayerLayer —— 最可靠的信号
        //    注意：直接翻 AVPlayerLayer 自身时，AVFoundation 在换分辨率/起播时会把它
        //    的 transform 重置回 identity（表现就是"翻了几秒又自己翻回去"）。
        //    所以优先翻它的**容器层**，容器层的 transform 没人动，翻上去就稳。
        if (DYMHasKey(layerName, kRenderLayerKeys)) {
            score = 100;
            if (v.layer.superlayer && v.layer.superlayer != gWindow.layer) {
                target = v.layer.superlayer;
            }
        } else {
            CALayer *render = DYMFindRenderSublayer(v.layer, 3);
            if (render) { score = 90; target = v.layer; }   // 翻容器，不翻渲染子层
        }

        // 2) 类名关键字（抖音直播常用 IESLivePlayerView / TTLivePlayerView / VEPlayer 等）
        if (score == 0) {
            if (DYMHasKey(viewName, kLiveViewKeys)) score = 70;
            else if (DYMHasKey(viewName, kPlayerKeys)) score = 60;
            else if (DYMHasKey(layerName, kLayerKeys)) score = 55;
        }

        // 3) 兜底：面积很大、层级较深、内部没有文字控件（视频层通常不带 UILabel）
        if (score == 0 && area >= winArea * 0.45 && depth >= 3 &&
            v.subviews.count <= 4 && !DYMHasLabelDescendant(v, 3)) {
            score = 30;
        }

        // 同等命中时优先取更大的层（嵌套的父容器会先被访问，得分一样时留面积大的）
        if (score > 0 && score >= best->score) {
            BOOL better = (score > best->score) || (score == best->score && area > best->area);
            if (better) { best->score = score; best->area = area; best->layer = target; }
        }
    }

    for (UIView *sub in v.subviews) {
        DYMWalk(sub, windowBounds, depth + 1, best);
    }
}

static CALayer *DYMFindBestLayer(NSInteger *outScore) {
    DYMCandidate best = { .score = 0, .area = 0, .layer = nil };
    NSArray<UIScene *> *scenes = UIApplication.sharedApplication.connectedScenes.allObjects;
    for (UIScene *scene in scenes) {
        if (![scene isKindOfClass:[UIWindowScene class]]) continue;
        UIWindowScene *ws = (UIWindowScene *)scene;
        if (ws.activationState == UISceneActivationStateBackground) continue;
        for (UIWindow *w in ws.windows) {
            if (w == gWindow) continue;
            if (DYMIsSystemWindow(w)) continue;
            CGRect bounds = w.bounds;
            DYMWalk(w, bounds, 0, &best);
            UIViewController *root = w.rootViewController;
            if (root && root.view) DYMWalk(root.view, bounds, 0, &best);
        }
    }
    if (outScore) *outScore = best.score;
    return best.layer;
}

#pragma mark - 镜像的应用 / 还原

static BOOL DYMVideoAlive(void) {
    if (!gVideoApplied || !gVideoLayer) return NO;
    id d = gVideoLayer.delegate;
    if ([d isKindOfClass:[UIView class]]) {
        UIView *v = (UIView *)d;
        return v.window != nil && !v.hidden && v.alpha > 0.05;
    }
    return gVideoLayer.superlayer != nil;
}

static BOOL DYMIsAncestorOrSelf(CALayer *a, CALayer *b) {
    CALayer *l = b;
    NSInteger guard = 0;
    while (l && guard++ < 64) {
        if (l == a) return YES;
        l = l.superlayer;
    }
    return NO;
}

static void DYMRestoreVideo(void) {
    if (gVideoApplied && gVideoLayer) {
        gVideoLayer.transform = gVideoOriginal;
    }
    gVideoApplied = NO;
    gVideoLayer = nil;
    gReapplyCount = 0;
}

static void DYMApplyVideo(CALayer *layer) {
    if (!layer || layer == gWindow.layer) return;

    CATransform3D m = CATransform3DMakeScale(-1, 1, 1);
    if (gVideoApplied && gVideoLayer == layer) {
        if (!CATransform3DEqualToTransform(layer.transform, m)) {
            layer.transform = m;
            gReapplyCount++;          // 被抖音还原了一次，立刻顶回去
        }
        return;
    }
    DYMRestoreVideo();
    gVideoOriginal = layer.transform;
    gVideoLayer = layer;
    gVideoApplied = YES;
    gReapplyCount = 0;
    layer.transform = m;
}

static void DYMRestoreFull(void) {
    for (CALayer *l in gFullLayers) {
        NSValue *v = gFullOriginal[[NSValue valueWithPointer:(__bridge const void *)l]];
        if (v) l.transform = v.CATransform3DValue;
    }
    [gFullLayers removeAllObjects];
    [gFullOriginal removeAllObjects];
}

// 整页模式：把每个前台窗口的根视图整体镜像（视频、背景一起翻）。
static void DYMApplyFull(void) {
    if (!gFullLayers) {
        gFullLayers = [NSMutableArray array];
        gFullOriginal = [NSMutableDictionary dictionary];
    }
    NSMutableArray<UIView *> *roots = [NSMutableArray array];
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes.allObjects) {
        if (![scene isKindOfClass:[UIWindowScene class]]) continue;
        UIWindowScene *ws = (UIWindowScene *)scene;
        if (ws.activationState == UISceneActivationStateBackground) continue;
        for (UIWindow *w in ws.windows) {
            if (w == gWindow || DYMIsSystemWindow(w)) continue;
            UIView *root = w.rootViewController.view ?: w;
            if (root.layer) [roots addObject:root];
        }
    }
    // 清理已经消失的图层
    NSMutableArray<NSValue *> *live = [NSMutableArray array];
    for (UIView *root in roots) [live addObject:[NSValue valueWithPointer:(__bridge const void *)root.layer]];
    for (CALayer *l in [gFullLayers copy]) {
        NSValue *key = [NSValue valueWithPointer:(__bridge const void *)l];
        if (![live containsObject:key]) {
            NSValue *v = gFullOriginal[key];
            if (v) l.transform = v.CATransform3DValue;
            [gFullOriginal removeObjectForKey:key];
            [gFullLayers removeObject:l];
        }
    }
    for (UIView *root in roots) {
        CALayer *l = root.layer;
        NSValue *key = [NSValue valueWithPointer:(__bridge const void *)l];
        if (!gFullOriginal[key]) {
            gFullOriginal[key] = [NSValue valueWithCATransform3D:l.transform];
            [gFullLayers addObject:l];
        }
        CATransform3D m = CATransform3DMakeScale(-1, 1, 1);
        if (!CATransform3DEqualToTransform(l.transform, m)) l.transform = m;
    }
}

#pragma mark - 悬浮按钮窗口

@implementation DYMOverlayWindow
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *v = [super hitTest:point withEvent:event];
    if (!v) return nil;
    if (v == self || v == self.rootViewController.view) return nil;   // 空白区域不拦截触摸
    return v;
}
@end

@implementation DYMOverlayController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.clearColor;

    UIButton *b = [UIButton buttonWithType:UIButtonTypeCustom];
    b.frame = CGRectMake(0, 0, 48, 48);
    b.layer.cornerRadius = 24;
    b.layer.masksToBounds = YES;
    b.layer.borderWidth = 1.0;
    b.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.55].CGColor;
    b.titleLabel.font = [UIFont boldSystemFontOfSize:15];
    [b setTitle:@"⇋" forState:UIControlStateNormal];
    b.titleLabel.textAlignment = NSTextAlignmentCenter;
    b.adjustsImageWhenHighlighted = NO;
    [b addTarget:self action:@selector(onTap) forControlEvents:UIControlEventTouchUpInside];

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(onPan:)];
    [b addGestureRecognizer:pan];

    UILongPressGestureRecognizer *lp = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(onLongPress:)];
    lp.minimumPressDuration = 0.55;
    [b addGestureRecognizer:lp];

    self.button = b;
    [self.view addSubview:b];
    [self refreshButton];
    [self restoreButtonPosition];
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations { return UIInterfaceOrientationMaskAll; }
- (BOOL)shouldAutorotate { return YES; }
- (BOOL)prefersStatusBarHidden { return NO; }

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    [self clampButton];
}

#pragma mark 外观

- (void)refreshButton {
    if (!self.button) return;
    self.button.backgroundColor = gEnabled
        ? [UIColor colorWithRed:0.04 green:0.52 blue:1.0 alpha:0.92]
        : [UIColor colorWithWhite:0.0 alpha:0.55];
    self.button.layer.borderColor = gEnabled
        ? [UIColor colorWithWhite:1.0 alpha:0.95].CGColor
        : [UIColor colorWithWhite:1.0 alpha:0.45].CGColor;
    [self.button setTitle:(gEnabled ? (gMode == 1 ? @"整" : @"⇋") : @"⇋")
                 forState:UIControlStateNormal];
    self.button.alpha = gEnabled ? 1.0 : 0.62;
}

- (void)restoreButtonPosition {
    UIWindow *w = self.view.window ?: gWindow;
    CGFloat ww = w.bounds.size.width, wh = w.bounds.size.height;
    CGRect safe = self.view.bounds;
    if (ww < 10 || wh < 10) ww = safe.size.width ?: 390, wh = safe.size.height ?: 844;

    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    CGFloat nx = [d objectForKey:kPosXKey] ? [d doubleForKey:kPosXKey] : 0.0;
    CGFloat ny = [d objectForKey:kPosYKey] ? [d doubleForKey:kPosYKey] : 0.0;
    if (nx <= 0 || ny <= 0) {           // 默认贴在右侧中部
        nx = 0.93; ny = 0.5;
    }
    self.button.center = CGPointMake(nx * ww, ny * wh);
    [self clampButton];
}

- (void)clampButton {
    if (!self.button) return;
    CGRect b = self.view.bounds;
    if (CGRectIsEmpty(b)) return;
    CGFloat half = 24, inset = 6;
    CGPoint c = self.button.center;
    c.x = MIN(MAX(c.x, half + inset), b.size.width  - half - inset);
    c.y = MIN(MAX(c.y, half + inset), b.size.height - half - inset);
    self.button.center = c;
}

#pragma mark 交互

- (void)onTap {
    DYMSetEnabled(!gEnabled);
    [self refreshButton];
}

- (void)onLongPress:(UILongPressGestureRecognizer *)g {
    if (g.state != UIGestureRecognizerStateBegan) return;
    [self showMenu];
}

- (void)onPan:(UIPanGestureRecognizer *)g {
    UIWindow *w = self.view.window ?: gWindow;
    CGPoint t = [g translationInView:w];
    CGPoint c = self.button.center;
    self.button.center = CGPointMake(c.x + t.x, c.y + t.y);
    [g setTranslation:CGPointZero inView:w];
    if (g.state == UIGestureRecognizerStateEnded || g.state == UIGestureRecognizerStateCancelled) {
        [self clampButton];
        CGSize s = w.bounds.size;
        if (s.width > 0 && s.height > 0) {
            NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
            [d setDouble:self.button.center.x / s.width  forKey:kPosXKey];
            [d setDouble:self.button.center.y / s.height forKey:kPosYKey];
            [d synchronize];
        }
    }
}

- (void)showMenu {
    NSString *detected = @"未识别到视频层";
    CALayer *best = DYMFindBestLayer(NULL);
    if (best) {
        id delegate = best.delegate;
        NSString *n = delegate ? NSStringFromClass([delegate class]) : NSStringFromClass(best.class);
        detected = [NSString stringWithFormat:@"当前识别：%@", n];
    }
    NSMutableString *msg = [NSMutableString stringWithString:detected];
    if (gVideoApplied && gVideoLayer) {
        id d = gVideoLayer.delegate;
        NSString *n = d ? NSStringFromClass([d class]) : NSStringFromClass(gVideoLayer.class);
        [msg appendFormat:@"\n当前锁定：%@（被重置 %lu 次）", n, (unsigned long)gReapplyCount];
    }
    [msg appendString:@"\n点按按钮 = 开/关镜像，拖动 = 换位置"];

    UIAlertController *ac = [UIAlertController alertControllerWithTitle:@"抖音镜像"
                                                              message:msg
                                                       preferredStyle:UIAlertControllerStyleActionSheet];
    __weak typeof(self) weakSelf = self;
    [ac addAction:[UIAlertAction actionWithTitle:@"关闭镜像" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *a) {
        DYMSetEnabled(NO); [weakSelf refreshButton];
    }]];
    [ac addAction:[UIAlertAction actionWithTitle:@"仅镜像视频画面（推荐）" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        gMode = 0; DYMSetEnabled(YES); [weakSelf refreshButton];
    }]];
    [ac addAction:[UIAlertAction actionWithTitle:@"镜像整个画面" style:UIAlertActionStyleDefault handler:^(UIAlertAction *a) {
        gMode = 1; DYMSetEnabled(YES); [weakSelf refreshButton];
    }]];
    [ac addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];

    if (ac.popoverPresentationController) {
        ac.popoverPresentationController.sourceView = self.button;
        ac.popoverPresentationController.sourceRect = self.button.bounds;
        ac.popoverPresentationController.permittedArrowDirections = 0;
    }
    [self presentAlert:ac];
}

- (void)presentAlert:(UIAlertController *)alert {
    UIViewController *top = self;
    while (top.presentedViewController) top = top.presentedViewController;
    [top presentViewController:alert animated:YES completion:nil];
}

- (void)showToast:(NSString *)text {
    UILabel *l = [[UILabel alloc] init];
    l.text = text;
    l.font = [UIFont systemFontOfSize:13 weight:UIFontWeightMedium];
    l.textColor = UIColor.whiteColor;
    l.backgroundColor = [UIColor colorWithWhite:0 alpha:0.78];
    l.textAlignment = NSTextAlignmentCenter;
    l.numberOfLines = 0;
    l.layer.cornerRadius = 12;
    l.layer.masksToBounds = YES;
    l.alpha = 0;

    CGSize max = CGSizeMake(self.view.bounds.size.width * 0.8, 200);
    CGRect r = [text boundingRectWithSize:max
                                  options:NSStringDrawingUsesLineFragmentOrigin
                               attributes:@{NSFontAttributeName: l.font}
                                  context:nil];
    CGFloat w = MIN(max.width, r.size.width + 28);
    CGFloat h = r.size.height + 20;
    l.frame = CGRectMake((self.view.bounds.size.width - w) / 2,
                         self.view.bounds.size.height * 0.72, w, h);
    l.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
    [self.view addSubview:l];

    [UIView animateWithDuration:0.2 animations:^{ l.alpha = 1; } completion:^(BOOL f) {
        [UIView animateWithDuration:0.35 delay:2.4 options:0 animations:^{ l.alpha = 0; } completion:^(BOOL f2) {
            [l removeFromSuperview];
        }];
    }];
}

@end

#pragma mark - 启动 / 停止

static void DYMPersist(void) {
    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    [d setBool:gEnabled forKey:kEnabledKey];
    [d setInteger:gMode   forKey:kModeKey];
    [d synchronize];
}

static void DYMSetEnabled(BOOL on) {
    gEnabled = on;
    DYMPersist();
    if (!on) {
        DYMRestoreVideo();
        DYMRestoreFull();
        gMissCount = 0;
        gWarnedReset = NO;
    } else {
        gMissCount = 0;
        DYMTick();
    }
    [gOverlay refreshButton];
    DYM_LOG("enabled=%d mode=%ld", (int)gEnabled, (long)gMode);
}

static void DYMTick(void) {
    UIApplication *app = UIApplication.sharedApplication;
    if (!app || app.applicationState != UIApplicationStateActive) return;

    // 悬浮按钮窗口：场景切换 / 旋转后重新对齐
    UIWindowScene *scene = DYMActiveScene();
    if (!gWindow || gWindow.windowScene != scene) {
        if (scene) { DYMEnsureOverlay(); }
    } else if (scene) {
        CGRect sb = scene.coordinateSpace.bounds;
        if (!CGRectEqualToRect(gWindow.frame, sb)) gWindow.frame = sb;
    }
    if (!gEnabled) return;

    if (gMode == 1) {
        DYMApplyFull();
        return;
    }


    NSInteger bestScore = 0;
    CALayer *best = DYMFindBestLayer(&bestScore);

    // 已经翻上的目标，只要它还在屏幕上就别换——换目标会先还原旧的，
    // 视觉上就是"翻了几秒又翻回去"。只有找到真正的渲染层（score>=90）才考虑换。
    BOOL keepCurrent = NO;
    if (DYMVideoAlive()) {
        BOOL better = best && bestScore >= 90 &&
                      !DYMIsAncestorOrSelf(best, gVideoLayer) &&
                      !DYMIsAncestorOrSelf(gVideoLayer, best);
        keepCurrent = !better;
    }

    if (keepCurrent) {
        gMissCount = 0;
        DYMApplyVideo(gVideoLayer);   // 继续翻老目标（顺便把抖音的重置顶回去）
    } else if (best) {
        gMissCount = 0;
        DYMApplyVideo(best);
    } else {
        gMissCount++;
        // 一次扫描失败不代表画面没了：只要旧目标还在窗口里就继续镜像，
        // 否则会出现"翻了几秒突然自己翻回去"。
        BOOL alive = NO;
        if (gVideoApplied && gVideoLayer) {
            id d = gVideoLayer.delegate;
            if ([d isKindOfClass:[UIView class]]) alive = (((UIView *)d).window != nil);
            else alive = (gVideoLayer.superlayer != nil);
        }
        if (!alive && gMissCount >= 3) DYMRestoreVideo();

        if (gMissCount == 20 && ![[NSUserDefaults standardUserDefaults] boolForKey:kHintedKey]) {
            [[NSUserDefaults standardUserDefaults] setBool:YES forKey:kHintedKey];
            [[NSUserDefaults standardUserDefaults] synchronize];
            dispatch_async(dispatch_get_main_queue(), ^{
                [gOverlay showToast:@"没找到视频画面层。可长按按钮 →「镜像整个画面」"];
            });
        }
    }

    if (gReapplyCount >= 8 && !gWarnedReset) {
        gWarnedReset = YES;
        dispatch_async(dispatch_get_main_queue(), ^{
            [gOverlay showToast:@"画面层一直在被抖音重置。可长按按钮 →「镜像整个画面」更稳"];
        });
    }
}

static UIWindowScene *DYMActiveScene(void) {
    UIApplication *app = UIApplication.sharedApplication;
    if (!app) return nil;
    UIWindowScene *fallback = nil;
    for (UIScene *s in app.connectedScenes) {
        if (![s isKindOfClass:[UIWindowScene class]]) continue;
        UIWindowScene *ws = (UIWindowScene *)s;
        if (ws.activationState == UISceneActivationStateForegroundActive) return ws;
        if (!fallback && ws.activationState != UISceneActivationStateBackground) fallback = ws;
    }
    if (!fallback) {
        for (UIScene *s in app.connectedScenes) {
            if ([s isKindOfClass:[UIWindowScene class]]) return (UIWindowScene *)s;
        }
    }
    return fallback;
}

static void DYMEnsureOverlay(void) {
    UIWindowScene *scene = DYMActiveScene();
    if (!scene) return;

    if (gWindow && gWindow.windowScene == scene && !gWindow.hidden) {
        return;
    }

    [gWindow setHidden:YES];
    gWindow = nil;
    gOverlay = nil;

    gOverlay = [[DYMOverlayController alloc] init];
    DYMOverlayWindow *w = [[DYMOverlayWindow alloc] initWithWindowScene:scene];
    w.frame = scene.coordinateSpace.bounds;
    w.rootViewController = gOverlay;
    w.backgroundColor = UIColor.clearColor;
    w.windowLevel = UIWindowLevelAlert + 100;
    w.hidden = NO;
    gWindow = w;

    [gOverlay refreshButton];
}

static void DYMStart(void) {
    if (gReady) { DYMEnsureOverlay(); return; }
    gReady = YES;
    DYMInitKeys();

    NSUserDefaults *d = [NSUserDefaults standardUserDefaults];
    gEnabled = [d boolForKey:kEnabledKey];
    gMode    = [d objectForKey:kModeKey] ? [d integerForKey:kModeKey] : 0;
    if (gMode < 0 || gMode > 1) gMode = 0;

    DYMEnsureOverlay();

    [gTimer invalidate];
    gTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 repeats:YES block:^(NSTimer *t) {
        @autoreleasepool { DYMTick(); }
    }];
    [NSRunLoop.mainRunLoop addTimer:gTimer forMode:NSRunLoopCommonModes];

    // 场景切换（全屏播放器可能换到另一个 scene/window）时重新挂按钮
    [[NSNotificationCenter defaultCenter] addObserverForName:UISceneDidActivateNotification
                                                      object:nil queue:NSOperationQueue.mainQueue
                                                  usingBlock:^(NSNotification *n) { DYMEnsureOverlay(); }];
    [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidBecomeActiveNotification
                                                      object:nil queue:NSOperationQueue.mainQueue
                                                  usingBlock:^(NSNotification *n) {
        DYMEnsureOverlay();
        if (!gTimer.isValid) {
            gTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 repeats:YES block:^(NSTimer *t) {
                @autoreleasepool { DYMTick(); }
            }];
            [NSRunLoop.mainRunLoop addTimer:gTimer forMode:NSRunLoopCommonModes];
        }
        DYMTick();
    }];

    NSLog(@"[DouyinMirror] loaded, enabled=%d mode=%ld", (int)gEnabled, (long)gMode);
}

__attribute__((constructor))
static void DYMConstructor(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        // 等 App 完成启动（有些 App 在 constructor 阶段还没有 UIApplication）
        if (UIApplication.sharedApplication) {
            DYMStart();
        } else {
            [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidFinishLaunchingNotification
                                                              object:nil queue:NSOperationQueue.mainQueue
                                                          usingBlock:^(NSNotification *n) { DYMStart(); }];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.4 * NSEC_PER_SEC)),
                           dispatch_get_main_queue(), ^{ DYMStart(); });
        }
    });
}
